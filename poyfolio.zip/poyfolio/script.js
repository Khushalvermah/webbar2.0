
let burger = document.querySelector('.burger');
let navbr = document.querySelector('.navigation');

burger.addEventListener('click', () => {

    navbr.classList.toggle('navresp');


});


let email = document.getElementById('email').value;
let  body = document.getElementsByClassName('mainpost').value;
let username = document.getElementsByClassName(mail).value;

